void main() {
	// 1. Mengenalkan variable dan memberi nilai pada variable
	double luas;
	int alas = 14;
	int tinggi = 5;
	double setengah = 1/2;

	// 2. Mejawab Rumus 
	luas = setengah * (alas * tinggi);

	// 3. Menampilkan Hasil
	print('Hasil luas ' + luas.toInt().toString());

}