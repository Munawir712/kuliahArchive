void main() {
	// 1. Mengenalkan variable dan memberi nilai pada variable
	int keliling;
	int sisi1 = 5;
	int sisi2 = 4;
	int sisi3 = 8;

	// 2. Menjawab rumus
	keliling = sisi1 + sisi2 + sisi3;

	print('Hasil dari keliling segitiga siku-siku: '+ keliling.toString());



}
	